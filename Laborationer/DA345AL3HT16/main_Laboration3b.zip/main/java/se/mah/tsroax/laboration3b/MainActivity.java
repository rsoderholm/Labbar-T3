package se.mah.tsroax.laboration3b;

import android.app.Activity;
import android.app.FragmentManager;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;


public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
    }

    private void initialize() {
        FragmentManager fm = getFragmentManager();
        WhatToDoFragment whatToDoFragment = (WhatToDoFragment)fm.findFragmentById(R.id.fragment_whatToDo);
        InstructionFragment instructionFragment = (InstructionFragment)fm.findFragmentById(R.id.fragment_instruction);
        Controller controller = new Controller(this,whatToDoFragment,instructionFragment);
    }

}
