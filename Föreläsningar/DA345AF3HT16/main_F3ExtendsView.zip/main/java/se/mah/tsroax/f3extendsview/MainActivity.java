package se.mah.tsroax.f3extendsview;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private String[] content = {"Detta", "är", "innehållet", "i", "en", "ListView", "rad7", "rad8"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initializeComponents();
    }

    private void initializeComponents() {
        ListView lvTrl = (ListView) findViewById(R.id.lvTrl);
        lvTrl.setAdapter(new TRLAdapter(this,content));
        lvTrl.setOnItemClickListener(new ListViewListener());
    }
//        lvTrl.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,content));
//        lvTrl.setAdapter(new ArrayAdapter<String>(this,R.layout.trl_row,content));
//        lvTrl.setAdapter(new TRLAdapter(this,content));

    private class ListViewListener implements AdapterView.OnItemClickListener {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            if(view instanceof TextView) {
                TextView tv = (TextView) view;
                Log.d("OICL", content[position] + " - " + tv.getText());
            } else if(view instanceof LinearLayout) {
                Log.d("OICL", content[position]);
            }
        }
    }
}