package se.mah.tsroax.f3dynamicrps;

public interface Input {
	public void setController(Controller controller);
	public void enableChoiceButtons(boolean enabled);
}
