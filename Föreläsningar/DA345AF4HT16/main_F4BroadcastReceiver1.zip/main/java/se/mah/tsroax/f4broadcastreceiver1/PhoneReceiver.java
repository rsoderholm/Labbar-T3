package se.mah.tsroax.f4broadcastreceiver1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * Created by tsroax on 06/09/15.
 */
public class PhoneReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d("PhoneReceiver", "start");
        if (intent != null) {
            String state = intent.getStringExtra(TelephonyManager.EXTRA_STATE);
            Log.d("PhoneReceiver", "EXTRA_STATE="+state);
            if (state.equals(TelephonyManager.EXTRA_STATE_RINGING)) {
                String phoneNumber = intent
                        .getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
                Log.d("PhoneReceiver", "EXTRA_INCOMING_NUMBER="+phoneNumber);
            }
        }

//        Intent startIntent = new Intent("se.mah.tsroax.f4startactivity.MainActivity");
//        Intent startIntent = new Intent(context,MainActivity.class);

//        startIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        context.startActivity(startIntent);
    }
}
