package se.mah.tsroax.f4broadcastreceiver2;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.telephony.TelephonyManager;
import android.widget.TextView;

public class MainActivity extends Activity {
    private PhoneReceiver phoneReceiver = new PhoneReceiver(this);
    private IntentFilter filter = new IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
//    private IntentFilter filter = new IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
    private TextView tvPhoneNumber;
    private TextView tvBattery;
    private boolean phoneReceiverReg = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvBattery = (TextView)findViewById(R.id.tvBattery);
        tvPhoneNumber = (TextView)findViewById(R.id.tvPhoneNumber);
        tvBattery.setText("Battery: " + getBatteryLevel() + "%");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)== PackageManager.PERMISSION_DENIED) {
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.READ_PHONE_STATE},0);
        }
        registerReceiver(phoneReceiver, filter);
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(phoneReceiver);
    }

    private int getBatteryLevel() {
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        Intent intent = registerReceiver(null, filter);
        int batteryLevel = 100 * (intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) / intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1));
        return batteryLevel;
    }

    public void setPhoneNumber(String phoneNumber) {
        tvPhoneNumber.setText(phoneNumber);
    }
}
